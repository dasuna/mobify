var saveCredentials = require('../lib/save-credentials');
var Utils = require('../lib/utils');

module.exports = function(grunt) {
    grunt.registerTask('mobify-save_credentials', 'Store your mobify cloud credentials', function(){
        var options = this.options({
            settingsPath: Utils.getSettingsPath()
        });

        var username = grunt.option('user');
        var key = grunt.option('key');

        return saveCredentials(username, key, options.settingsPath);
    });
};