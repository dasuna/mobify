'user-strict';

var Utils = require('../lib/utils');


var ARCHIVE = 'build.tar';
var DEFAULT_ORIGIN = 'https://cloud.mobify.com';


module.exports = function(grunt) {
    grunt.registerMultiTask('mobify-upload', 'Upload a bundle to the Mobify Cloud', function() {
        var taskComplete = this.async();

        var options = this.options({
            projectSlug: '',
            settingsFile: Utils.getSettingsPath(),
            origin: DEFAULT_ORIGIN,
            target: '',
            message: ''
        });

        function upload() {
            if (!grunt.file.exists(ARCHIVE)) {
                grunt.fail.fatal('Failed to create the bundle.');
            }

            var buildObj = Utils.buildObject(ARCHIVE, options.message);
            var buildJSON = JSON.stringify(buildObj, null, 4);
            var dataBuffer = new Buffer(buildJSON);

            var requestOptions = {
                auth: Utils.readCredentials(options.settingsFile),
                dataLength: dataBuffer.length,
                origin: options.origin,
                projectSlug: options.projectSlug,
                target: options.target
            };

            Utils.buildRequest(requestOptions, function(data) {
                grunt.log.ok('Build Uploaded!');
                grunt.log.ok('Link to preview the bundle:', data['bundle_preview_url']);
                taskComplete();
            }).end(dataBuffer)
        }

        Utils.createBundle(this.filesSrc, options.projectSlug, ARCHIVE, upload);
    });
};