'use-strict';

var fs = require('fs');
var path = require('path');

var Request = require('request');

var Utils = require('../lib/utils');


var NAME = 'mobify-verify_adaptive_dependencies';
var DESCRIPTION = 'Verifies dependencies against the Mobify Cloud';


module.exports = function(grunt) {
    grunt.registerTask(NAME, DESCRIPTION, function() {
        var done = this.async();

        var options = this.options({
            projectSlug: '',
            basePath: process.cwd(),
            origin: 'https://cloud.mobify.com',
            settingsFile: Utils.getSettingsPath()
        });

        var uri = Utils.getProjectApiPath(
            options.origin, options.projectSlug,
            "adaptivejs/verify-dependencies/"
        );

        var form = {};
        ['package.json', 'bower.json'].forEach(function(filename) {
            form[filename] = fs.readFileSync(
                path.join(options.basePath, filename),
                { encoding: 'utf8' }
            );
        });

        var requestOptions = {
            auth: Utils.readCredentials(options.settingsFile),
            headers: Utils.getRequestHeaders(),
            form: form
        };

        Request.post(uri, requestOptions, function(error, response, body) {
            if (error || (error = Utils.errorForStatus(response))) {
                if (error.code == 'ECONNREFUSED') {
                    var message = 'Unable to connect to ' + options.origin + '. Check your connection and try again.\n' +
                                  'For more information visit ' + DEFAULT_DOCS_URL + '.';
                    grunt.fail.warn(message);
                }
                grunt.fail.warn(error.message);
            }

            var result = null;
            try {
                result = JSON.parse(body);
            } catch(e) {
                grunt.fail.warn("Could not verify Adaptive.js dependencies, got response:\r\n" + body);
            }

            if (!result.success) {
                grunt.fail.warn(result.message);
            }

            done();
        });
    });
};
