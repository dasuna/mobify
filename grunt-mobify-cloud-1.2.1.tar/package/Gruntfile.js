'use strict';

var path = require('path');

var settingsPath = 'test/fixtures/creds';


module.exports = function(grunt) {
    grunt.initConfig({
        express: {
            custom: {
                options:{
                    port: 3000,
                    hostname: 'localhost',
                    server: 'test/mock-server.js'
                }
            }
        },
        'mobify-verify_adaptive_dependencies': {
            options: {
                projectSlug: 'test-project',
                basePath: path.join(process.cwd(), 'test/fixtures'),
                origin: 'https://localhost:3000',
                settingsFile: settingsPath
            }
        },
        'mobify-upload': {
            options: {
                settingsFile: settingsPath,
                origin: grunt.option('origin') || 'https://localhost:3000',
                projectSlug: grunt.option('project') || 'test-project',
                message: grunt.option('message') || '',
                target: grunt.option('deploy-to-target') || ''
            },
            src: ['test/**', '!test/fixtures/creds']
        },
        'mobify-save_credentials': {
            options: {
                settingsPath: './.mobify'
            }
        },
        nodeunit: {
            tests: ['test/test-*.js']
        },
        release: {
            options: {
                folder: '.',
                github: {
                    repo: 'mobify/grunt-mobify-cloud',
                    usernameVar: 'GITHUB_USERNAME',
                    passwordVar: 'GITHUB_TOKEN'
                }
            }
        }
    });

    grunt.loadTasks('tasks');

    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-nodeunit');
    grunt.loadNpmTasks('grunt-express');
    grunt.loadNpmTasks('grunt-release');

    grunt.registerTask('test', ['express', 'mobify-verify_adaptive_dependencies', 'mobify-upload', 'nodeunit']);
    grunt.registerTask('default', ['jshint', 'test']);
};