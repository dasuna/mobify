# Grunt Tasks

`grunt-mobify-cloud` provides three Grunt tasks used for building Adaptive.js projects:
* `mobify-upload`: Builds a bundle and pushes it to the Mobify Cloud using saved credentials.
* `mobify-save_credentials`: Saves your Mobify Cloud credentials.
* `mobify-verify_adaptive_dependencies`: Verifies that the installed dependancies are valid.

## mobify-upload

Builds a bundle and pushes it to the Mobify Cloud using your saved credentials.

```
'mobify-upload': {
    options: {
        projectSlug: 'mobify-test',
        settingsFile: './.local-settings'
    },
    src: ['bld/**', '!bld/test/test-credentials']
}
```

Refer to [Grunt's globbing patterns](http://gruntjs.com/api/grunt.file#globbing-patterns)
to specify file paths.

### Options

* `origin`: Where to upload the bundle. Defaults to `https://cloud.mobify.com/`.

  ```sh
  grunt mobify-upload --origin="http://cloud-test.mobify.com/"
  ```

* `message`: A descriptive message to be associated with the bundle.

  ```sh
  grunt mobify-upload --message="An informative and witty bundle message."
  ```

* `deploy-to-target`: Deploys the bundle to a target after it is uploaded.
  Useful for build servers.

  ```sh
  grunt mobify-upload --deploy-to-target="ci-development"
  ```

## mobify-save_credentials

Stores your email and API key so it can be used for uploads.

```
'mobify-save_credentials': {
    // The location where the credentials will be stored.
    src: '/Users/myself/.mobify'
}
```

To save your credentials:

```sh
grunt mobify-save_credentials --user="user@mobify.com" --key="5up3rR4Nd0mK3y"
```

## mobify-verify_adaptive_dependencies

Verifies your `package.json` and `bower.json` files against the Mobify Cloud.

```sh
grunt mobify-verify_adaptive_dependencies
```

# Deployment

To deploy this plugin you need to specify some environment variables that specify your github username and password.

```sh
export GITHUB_USERNAME='foobarnerson'
export GITHUB_PASSWORD='myaccesstoken'
```

# Development

## Testing

```sh
grunt test
```

## Releasing

To release a new version of this package:

0. `grunt test`
1. Bump version in `package.json`.
2. Update the `CHANGELOG`.
3. [Create a new release on GitHub](https://github.com/mobify/grunt-mobify-cloud/releases/new).
4. `npm publish`